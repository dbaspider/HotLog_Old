Created by: ARIOX.COM

StrUtils unit
*************

The StrUtils unit implements two String functions to Delphi called:
RightStr and LeftStr similar to the (Right and Left) found in
Visual Basic

Just include the StrUtils unit to your application and you are ready
to go:

Example:

text := RightStr('Alexis Rios', 4);

equals

text = 'Rios'


text := LeftStr('Alexis Rios', 6);

equals

text = 'Alexis'


INSTALLATION
************

1. Copy the StrUtils.pas into the folder

	C:\Program Files\Borland\Delphi5\Source\VCL

2. Copy the StrUtils.dcu into the folder

	C:\Program Files\Borland\Delphi5\Lib


If you are not using Delphi 5 then re-compile the StrUtils.pas
to get the StrUtils.dcu for your version of Delphi and follow the
INSTALLATION steps.

Enjoy!!!!